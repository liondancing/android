Collection of some interesting links (updated time to time)
====  


## Types of Biometrics

https://www.biometricsinstitute.org/what-is-biometrics/types-of-biometrics/

## HOWTO SETUP

FaceUnlock: https://www.xda-developers.com/face-unlock/

Fingerprint: https://www.wikihow.com/Set-Up-the-Fingerprint-Scanner-on-an-Android-Device

IrisUnlock: https://www.samsung.com/ph/support/mobile-devices/what-is-iris-scanning-and-how-to-use-it-on-my-samsung-galaxy-device/


### Others:

## EN: 
https://blog.kraken.com/post/11905/your-fingerprint-can-be-hacked-for-5-heres-how/

https://arxiv.org/pdf/2305.10791.pdf

https://securitycafe.ro/2022/09/05/mobile-pentesting-101-bypassing-biometric-authentication/

https://hackerone.com/reports/637194

https://www.darkreading.com/endpoint/bruteprint-short-work-fingerprint-security

## RU:

https://fi5t.xyz/posts/biometrics-how-it-works/

https://fi5t.xyz/posts/biometrics-in-android/

https://fi5t.xyz/posts/biometrics-attacks/ 



https://www.youtube.com/watch?v=kYhVfT7ZpUE
