package dev.skomlach.biometric.compat.crypto.rsa

class RsaKeyDataException(errorMsg: String?) : Exception(errorMsg)